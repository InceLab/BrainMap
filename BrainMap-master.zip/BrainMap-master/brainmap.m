%run averag map window
bmp=BrainMap;
bmp.BuildFig();